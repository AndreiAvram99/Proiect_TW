<?php

class Ranking{

    public function __construct(){

    }

//    to do: functiile de get nu stiu ce valori

    public function show(){
        include("./../View/ranking_view.php");
    }
}