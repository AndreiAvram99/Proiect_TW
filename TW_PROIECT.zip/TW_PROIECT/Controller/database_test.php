<?php
include("../Model/database_model.php");

$dbi = database::get_dbi();