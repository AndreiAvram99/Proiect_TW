<div class="container-row">
    <label class="radio-style"> <?php echo $this->get_value()?>
        <input type="radio" name=<?php echo $this->get_name();?> value=<?php echo $this->get_value();?>>
        <span class="radio-checkmark"></span>
    </label>
</div>