<!--to do: sa iei valorile din controller prin functiile de get-->

<table class = "ranking">
    <tr><th>Name</th><th>Activity</th></tr>
    <tr><td>Name 1</td><td>Value 1</td></tr>
    <tr><td>Name 2</td><td>Value 2</td></tr>
    <tr><td>Name 3</td><td>Value 3</td></tr>
    <tr><td>Name 4</td><td>Value 4</td></tr>
</table>

<table class = "ranking">
    <tr><th>Name</th><th>Activity</th></tr>
    <tr><td>Name 1</td><td>Value 1</td></tr>
    <tr><td>Name 2</td><td>Value 2</td></tr>
    <tr><td>Name 3</td><td>Value 3</td></tr>
    <tr><td>Name 4</td><td>Value 4</td></tr>
</table>